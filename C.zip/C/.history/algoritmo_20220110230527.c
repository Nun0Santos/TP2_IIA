#include "globals.h"
#include "algoritmo.h"
#include "utils.h"

#define PROB 0.1

void geraVizinho(int a[], int b[], int c[],int n)
{
  int i, pos, pos_ant;

    for(i=0; i<n; i++) {
        b[i]=a[i];
        c[i]=a[i];
    }
	
    pos=random_l_h(0, n-1);
    if(b[pos] == 1) {
        b[pos] = 0;
    }else
        b[pos] = 1;

    pos_ant = pos;
    
    do {
        pos = random_l_h(0, n-1);
    }while(pos == pos_ant);
    
	
    if(c[pos] == 1)
        c[pos] = 0;
    else
        c[pos] = 1;

} 


/*int tudoZeros(int *sol,int v){
    for(int i = 0 ; i< v ;i++){
        if(sol[i]!=0)
            return 0;
    }
    return 1;
} */

int trepa_colinas(int sol[], int *mat, int vert, int num_iter)
{
     int custo, custo_viz, i;
    double prob;

	int vizinho1[vert];
    int vizinho2[vert];
    int nova_sol[vert];

    do {
        //Gere sol inicial
        gera_sol_inicial(sol, vert);			

        //Calcula fitness de sol inicial
        custo = calcula_fit(sol, mat, vert);
        //printf("12");
    }while(custo == -1); //Enquanto o custo da solucao inicial for -1 (ser invalida) originar outra

    
    //Escrever sol inicial
    escreve_sol(sol, vert);
    printf("Custo inicial = %d\n", custo);
    
    for(i=0; i<num_iter; i++)
    {
		do{
            // Gera vizinho
            gera_vizinho(sol, vizinho1, vizinho2, vert);
            // Avalia melhor vizinho
            custo_viz = melhorVizinho(nova_sol, vizinho1, vizinho2, mat, vert);
        }while(custo_viz == -1);
        
        if(custo_viz >= custo)
        {
			substitui(sol, nova_sol, vert);
			custo = custo_viz;
        }
    }
    return custo;
}


//Parte 2

void torneioSelecao(pchrom pop, struct info *d, pchrom pais){
    int a,b;


    for(int i = 0; i < d->popsize;i++){

        //gero um indice aleatorio
        a = random_l_h(0,(d->popsize-1));

        // gero outro indice aleatorio ate ambos serem diferentes
        do
            b = random_l_h(0,(d->popsize-1));
        while(a == b);

        if(pop[a].fitness > pop[b].fitness)
            pais[i] = pop[a];
        else
            pais[i] = pop[b];
    }
}


void recombinacao(pchrom pais, struct info *d, pchrom filhos){

    //ponto de corte aleatorio
    int ponto,j;

    for(int i = 0; i < d->popsize; i+=2){

        // vai haver ponto de corte
        if(rand_01() < d->pr){
            ponto = random_l_h(0, d->capacidade-1);
            for(j = 0; j < ponto; j++){
                // passamos ao mesmo tempo os numeros ate ao ponto de corte
                filhos[i].p[j] = pais[i].p[j];
                filhos[i+1].p[j] = pais[i+1].p[j];
            }
            // preenchemos o primeiro filho
            if(j == ponto){
                for(int x = j; x < d->capacidade; x++)
                    filhos[i].p[x] = pais[i+1].p[x];
            }
            // preenchemos o segundo filho
            j = ponto;
            for(int x = j; x < d->capacidade; x++)
                filhos[i+1].p[x] = pais[i].p[x];
        }

        else{
            // faz uma copia exata porque nao houve a pr
            filhos[i] = pais[i];
            filhos[i+1] = pais[i+1];
        }
    }
}



void mutacao(pchrom filhos, struct info *d){
    int num;

    for(int i = 0; i < d->popsize; i++){
        for(int j = 0; j < d->capacidade; j++){
            if(rand_01() < d->pm){

                // encontramos um nr aleatorio != do nr atual
                do{
                    num = random_l_h(0,(d->numSub-1));
                }while(num == filhos[i].p[j]);

                // alteramos o nr atual pelo num
                filhos[i].p[j] = num;
            }
        }
    }
}