#include "funcao.h"
# include "utils.h"
#include "algoritmo.h"

// Calcula a qualidade de uma solu��o
// Recebe:  A solu��o, a, a matriz de adjac�ncias, mat, e o n�mero de v�rtices, vert
// Devolve: O custo que � o n�mero de liga��es que existem na solu��o
int calcula_fit(int a[], int *mat, int vert)
{
	int total=0;
	int i, j;

	for(i=0; i<vert; i++)
		if(a[i]==1)
		{
            for (j = 0; j < vert; ++j) {
                if(a[j] == 1 && mat[i*vert+j] == 1){ 
                    return -1;
                }
            }
		}

    for (int k = 0; k < vert; ++k) {
        if(a[k] == 1){
            ++total;
        }
    }
	
    return total;
}

int melhorVizinho(int a[], int b[], int c[], int *mat, int vert){
    int custo_b, custo_c;

    custo_b = calcula_fit(b, mat, vert);
    custo_c = calcula_fit(c, mat, vert);

    if(custo_b == -1 && custo_c == -1){

        return -1;   
    }   
    else if(custo_c == -1) {    
        for(int i = 0; i < vert; ++i){
            a[i] = b[i];
        }

        return custo_b;
    }else if(custo_b == -1){
        for(int i = 0; i < vert; ++i){
            a[i] = c[i];
        }

        return custo_c;
        
    }else if(custo_b < custo_c){
        for(int i = 0; i < vert; ++i){
            a[i] = c[i];
        }

        return custo_c;
    }else {
        for(int i = 0; i < vert; ++i){
            a[i] = b[i];
        }

        return custo_b;
    }
}
//evolutivos

// Calcula a qualidade de uma solu��o
// Par�metros de entrada: solu��o (sol), capacidade da mochila (d), matriz com dados do problema (mat) e numero de objectos (v)
// Par�metros de sa�da: qualidade da solu��o (se a capacidade for excedida devolve 0)
float eval_individual(int sol[], struct info d, int *mat, int *v){
	int     i, min;
	float   ro;

		if (solucaovalida(sol, d.numGenes, mat) == 0) { // solução inválida
				int x=0;
				int num_verts_sol = random_l_h(0, d.numGenes-1);
				for(int j=0; j<d.numGenes; j++){
					do{																	//ISTO SECALHAR N È PRECISO
						x = random_l_h(0, d.numGenes-1);
					}while(sol[x] == 0);
					sol[x]=1;
				}
				*v =0;
				//penalização
				/**v = 1;
				int fit = calcula_fit(sol,mat,d.numGenes);
				return fit - //Funcao NUM_ARESTAS_DA_SOLUCAO - 1*/
		} else {
			*v = 1;
		}

	int fit = calcula_fit(sol,mat,d.numGenes);
	if (*v == 0 ) fit = 0;
	// v é a validade da solução (0 - inválido, 1 - válido)
	return fit;
}
int solucaovalida(int *sol, int v, int * mat){
    int i=0, j=0;
    for(i=0; i<v; i++)
		if(sol[i]==1)
		{
			for(j=0; j<v;j++)
				if(sol[j]==1 && mat[i*v+j]==1)
                    return 0; 

		}
    return 1;
}

// Avaliacao da popula��o
// Par�metros de entrada: populacao (pop), estrutura com parametros (d) e matriz com dados do problema (mat)
// Par�metros de sa�da: Preenche pop com os valores de fitness e de validade para cada solu��o
void evaluate(pchrom pop, struct info d, int *mat)
{
	int i;

	for (i=0; i<d.popsize; i++)
		pop[i].fitness = eval_individual(pop[i].p, d, mat, &pop[i].valido);
		
}

// Calcula a qualidade de uma solu��o
// Recebe:  A solu��o, a, a matriz de adjac�ncias, mat, e o n�mero de v�rtices, vert
// Devolve: O custo que � o n�mero de liga��es que existem na solu��o
int calcula_fit1(int sol[], int vert)
{
	int total=0;
	int i;

	for(i=0; i<vert; i++)
		if(sol[i] == 1)
			total++;

	return total;
}