#include "globals.h"
#include "utils.h"

// Leitura do ficheiro de input
// Recebe: nome do ficheiro, numero de vertices (ptr), numero de iteracoes (ptr)
// Devolve a matriz de adjacencias
int* init_dados(char *nome, int *n, int *iter)
{
	FILE *f;
	int *p, *q;
	int i, j;
	char buffer[50];
	
	f=fopen(nome, "rt");
	if(!f)
	{
		
		perror("Erro no acesso ao ficheiro dos dados\n");
		exit(1);
	}


	do {
		fscanf(f, "%s ", buffer);
	}while(strcmp(buffer, "p") != 0);


	fscanf(f, " edge %d %d", n, iter);


	// Alocacao dinamica da matriz
	p = malloc(sizeof(int) * (*n) * (*n));

	if(!p)
	{
	    printf("Erro na alocacao de memoria\n");
	    exit(1);
	}

    int k = 0;
    while(k < (*n)*(*n)){
        p[k] = 0;
        ++k;
    }


    int n1 = 0, n2 = 0;
	// Preenchimento da matriz
	for(i=0; i<*iter; i++){
        fscanf(f, " e %d %d", &n1, &n2);
        p[(n1-1)*(*n)+(n2-1)] = 1;
    }


    fclose(f);
	return p;
}

// Gera a solucao inicial
// Parametros: numero de vertices
void gera_sol_inicial(int sol[], int v)
{
	int x, n;

	for(int i=0; i < v; i++){
		sol[i]=0;
	}

	n = random_l_h(2, v);

    for (int k = 0; k < n; ++k) {
        do{
            x = random_l_h(0,v-1);
        }while(sol[x] != 0);

        sol[x] = 1;
    }
}

// Escreve solucao
// Parametros: solucao e numero de vertices
void escreve_sol(int *sol, int vert)
{
	int i;

	printf("\nSolucao com vertices: ");
	for(i=0; i<vert; i++)
		if(sol[i]==1)
			printf("%2d  ", i+1);

	printf("\nSolucao binaria: ");
	for(i=0; i<vert; i++)
		printf("%d  ", sol[i]);
	printf("\n");
}

// copia vector b para a (tamanho n)
void substitui(int a[], int b[], int n)
{
    int i;
    for(i=0; i<n; i++)
        a[i]=b[i];
}

// Inicializa o gerador de numeros aleatorios
void init_rand()
{
	srand((unsigned)time(NULL));
}

// Devolve valor inteiro aleatorio entre min e max
int random_l_h(int min, int max)
{
	return min + rand() % (max-min+1);
}

// Devolve um valor real aleatorio do intervalo [0, 1]
float rand_01()
{
	return ((float)rand())/RAND_MAX;
}

//Algumas funcoes uteis
void apagar_ecra()      //Funcao que deteta o sistema e apaga o ecra
{
    #ifdef WINDOWS
        system("cls");
    #else
        system ("clear");
    #endif
}

void mostrarMenu(){         
    printf("\n---------- MENU ----------\n");
    printf("1 - Trepa Colinas\n");
    printf("2 - Algoritmo Evolutivo\n");
    printf("3 - Algoritmo Hibrido\n");
    printf("4 - Sair\n");
    printf("Selecione o numero da opcao: ");
}
//Evolutivos







// Criacao da populacao inicial. O vector e alocado dinamicamente
// Par�metro de entrada: Estrutura com par�metros do problema
// Par�metro de sa�da: Preenche da estrutura da popula��o apenas o vector bin�rio com os elementos que est�o dentro ou fora da mochila
pchrom init_pop(struct info x)
{
	int     i, j, r;
	pchrom  indiv;

	indiv = malloc(sizeof(chrom)*x.popsize);
	if (indiv==NULL){
		printf("Erro na alocacao de memoria\n");
		exit(1);
	}
	
	for (i=0 ; i < x.popsize ; i++)
	{
		for (j=0; j < x.vert ; j++)
			indiv[i].p[j] = 0;
	}

	i = j = 0;
	
        for(i=0 ; i < x.popsize ; i++){
			int num_verts_sol = random_l_h(0, x.vert-1);
			for(j = 0; j < num_verts_sol; j++){
				do{
					r = random_l_h(0, x.vert -1);
				}while(indiv[i].p[r] != 0);
				indiv[i].p[r] = 1;
			}
		}
		
	return indiv;
}
// Actualiza a melhor solu��o encontrada
// Par�metro de entrada: populacao actual (pop), estrutura com par�metros (d) e a melhor solucao encontrada at� a gera��oo imediatamente anterior (best)
// Par�metro de sa�da: a melhor solucao encontrada at� a gera��o actual
chrom get_best(pchrom pop, struct info d, chrom best)
{
	int i;

	for (i=0; i<d.popsize; i++) //popsize é o tamanho do array pop
	{
		if (best.fitness < pop[i].fitness && pop[i].valido == 1)
			best=pop[i];
	}
	return best;
}
// Escreve uma solu��o na consola
// Par�metro de entrada: populacao actual (pop) e estrutura com par�metros (d)
void write_best(chrom x, struct info d)
{
	int i;

	printf("\nMelhor Individual: %4.1f\n", x.fitness);
	for (i=0; i<d.vert; i++)
		printf("%d", x.p[i]);
		
	putchar('\n');
}
// Leitura dos par�metros e dos dados do problema
// Par�metros de entrada: Nome do ficheiro e matriz a preencher com os dados dos objectos (peso e valor)
// Par�metros de sa�da: Devolve a estrutura com os par�metros
