#include "globals.h"
#include "algoritmo.h"

int* init_dados(char *nome, int *n, int *iter);
void gera_sol_inicial(int sol[], int v);
void escreve_sol(int *sol,int vert);
void substitui(int a[], int b[], int n);


void init_rand(void);
int random_l_h(int min, int max);
float rand_01(void);


//Evolutivos
int* lerFicheiro(char *nome , struct info *x);
pchrom init_pop(struct info x);
    void print_pop(pchrom pop, struct info d);
chrom get_best(pchrom pop, struct info d, chrom best);
void write_best(chrom x, struct info d);
    int flip();


//Funcoes para o ecra
void apagar_ecra(); //Funcao que deteta o sistema e apaga o ecra
void mostrarMenu();