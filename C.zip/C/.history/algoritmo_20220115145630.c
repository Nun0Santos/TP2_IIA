#include "algoritmo.h"
#

// Gera um vizinho
// Parametros: solucao actual, vizinho 1, vizinho 2, numero de vertices
//swap two vertices
void gera_vizinho(int a[], int b[], int c[], int n)
{
    int i, pos, pos_ant;

    for(i=0; i<n; i++) {
        b[i]=a[i];
        c[i]=a[i];
    }
    pos=random_l_h(0, n-1);
    if(b[pos] == 1) {
        b[pos] = 0;
    }else
        b[pos] = 1;

    pos_ant = pos;
    
    do {
        pos = random_l_h(0, n-1);
    }while(pos == pos_ant);
    
    if(c[pos] == 1)
        c[pos] = 0;
    else
        c[pos] = 1;
}

// Trepa colinas first-choice
// Parametros: solucao, matriz de adjacencias, numero de vertices e numero de iteracoes
// Devolve o custo da melhor solucao encontrada
int trepa_colinas(int sol[], int *mat, int vert, int num_iter)
{
    int custo, custo_viz, i;
    double prob;

	int vizinho1[vert];
    int vizinho2[vert];
    int nova_sol[vert];

    do {
        gera_sol_inicial(sol, vert);//Gere sol inicial		
        custo = calcula_fit(sol, mat, vert);//Calcula fitness de sol inicial
        
    }while(custo == -1); //Enquanto o custo da solucao inicial for -1 (ser invalida) originar outra

    escreve_sol(sol, vert); //Escrever sol inicial
    printf("Custo inicial = %d\n", custo);
    
    for(i=0; i<num_iter; i++)
    {
		do{
            gera_vizinho(sol, vizinho1, vizinho2, vert);  // Gera vizinho
            custo_viz = melhorVizinho(nova_sol, vizinho1, vizinho2, mat, vert);// Avalia melhor vizinho

        }while(custo_viz == -1);
        
        if(custo_viz >= custo)
        {
			substitui(sol, nova_sol, vert);
			custo = custo_viz;
        }
    }
    return custo;
}

//Evolutivos

// Preenche uma estrutura com os progenitores da próxima geração, de acordo com o resultados do torneio binario (tamanho de torneio: 2)
// Parâmetros de entrada: populaçãoo actual (pop), estrutura com parâmetros (d) e população de pais a encher
void tournament(pchrom pop, struct info d, pchrom parents){
	int i, temp,max;
	// Realiza popsize torneios
	for(i=0; i<d.popsize;i++) // tamanho do array pop com as soluções
	{
		max = random_l_h(0, d.popsize-1);
		do
			temp = random_l_h(0,d.popsize - 1);

		while(temp == max);

		if(pop[max].fitness > pop[temp].fitness) 
			parents[i] = pop[max];
		else
			parents[i]=pop[temp];	
	}
}

// Operadores geneticos a usar na gera��o dos filhos
// Par�metros de entrada: estrutura com os pais (parents), estrutura com par�metros (d), estrutura que guardar� os descendentes (offspring)
void genetic_operators(pchrom parents, struct info d, pchrom pop)
{
    // Recombinaçãoo com um ponto de corte
	crossover(parents, d, pop); // quando sucesso na probabilidade de recombinação, pop fica com metade dos bits do parent e mantém metade dos seus
	// Mutação binária
	mutation(pop, d); // para cada bit de cada solução vê atravéz da probabilidade de mutação se lhe dá flip
}

// Preenche o vector descendentes com o resultado das operadores de recombinação
// Parâmetros de entrada: estrutura com os pais (parents), estrutura com parâmetros (d), estrutura que guardar os descendentes (offspring)
void crossover(pchrom parents, struct info x, pchrom offspring)
{
	int i, j, point;

	for (i=0; i<x.popsize; i+=2) // tam de parents
	{
		if (rand_01() < x.pr) // rand_01 retorna um valor entre 0 e 1, pr = probabilidade de recombinação
		{
			point = random_l_h(0, x.vert - 1); 
			for (j=0; j<point; j++)
			{
				offspring[i].p[j] = parents[i].p[j];
				offspring[i+1].p[j] = parents[i+1].p[j];
			}
			for (j = point; j< x.vert ; j++)
			{
				offspring[i].p[j] = parents[i+1].p[j];
				offspring[i+1].p[j] = parents[i].p[j];
			}
		}else{
			offspring[i] = parents[i];
			offspring[i+1] = parents[i+1];
		}
	}
}

// Muta��o bin�ria com v�rios pontos de muta��o
// Par�metros de entrada: estrutura com os descendentes (offspring) e estrutura com par�metros (d)
void mutation(pchrom offspring, struct info x)
{
    int i, j;

	for(i = 0 ; i < x.popsize ; i++)
    	for (j=0; j < x.vert; j++)
        	if (rand_01() < x.pm)
            	offspring[i].p[j] = !(offspring[i].p[j]);
                
}