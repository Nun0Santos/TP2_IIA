#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>
#define MAX_OBJ 1000		// Numero maximo (de objectos ) de numGenes