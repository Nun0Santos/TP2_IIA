#include "algoritmo.h"

int calcula_fit(int a[], int *mat, int vert);
int melhorVizinho(int a[], int b[], int c[], int *mat, int vert);

void evaluate(pchrom pop, struct info d, int *mat);
//int calcula_fit1(int a[], int vert);
int solucaovalida(int *sol, int v, int * mat);