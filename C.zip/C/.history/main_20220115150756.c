#define _CRT_SECURE_NO_WARNINGS 1
#include "globals.h"
#include "algoritmo.h"
#include "funcao.h"
#include "utils.h"

int main(int argc, char *argv[])
{
    char    nome_fich[100];
    int     vert, num_iter, k, runs, custo, best_custo=0, op=0;
    int     *grafo, *sol, *best,it;
	float   mbf = 0.0;

	struct info EA_param;
	pchrom      pop = NULL, parents = NULL;
	chrom       best_run, best_ever;
	int         gen_actual, r, i, inv;
	int *matriz;

	if(argc == 3)
	{
		runs = atoi(argv[2]);
		strcpy(nome_fich, argv[1]);
	}
	else
        if(argc == 2)
        {
            runs = DEFAULT_RUNS;
            strcpy(nome_fich, argv[1]);
        }
        else
        {
            runs = DEFAULT_RUNS;
            printf("Nome do Ficheiro: ");
            gets(nome_fich);
        }
	if(runs <= 0)
		return 0;
	init_rand();

   

	/* ================== MENU ================== */
	while(1){
        mostrarMenu();
        scanf("%d",&op);

		switch (op){
			case 1: /* TREPA COLINAS */
					// Preenche matriz de adjacencias
					grafo = init_dados(nome_fich, &vert, &num_iter);
					best = malloc(sizeof(int)*vert);
					sol = malloc(sizeof(int)*vert);

					if(sol == NULL || best == NULL)
					{
						printf("Erro na alocacao de memoria");
						exit(1);
					}
					printf("Iterações :",it);
					scanf("%d",&it);
					for(int i =0; i<it; i++){
						printf("%d",it);
						for(k=0; k<runs; k++) {
							if(k != 0) {
							printf("------------------\n");
							}
							custo = trepa_colinas(sol, grafo, vert, num_iter);
							// Escreve resultados da repeticao k
							printf("\nRepeticao %d:", k);
							escreve_sol(sol, vert);
							printf("Custo final: %2d\n", custo);
							mbf += custo;
							if(k==0 || best_custo < custo)
							{
							best_custo = custo;
							substitui(best, sol, vert);
							}
						}
					}
						// Escreve emakeresultados globais
						printf("\n\nMBF: %f\n", mbf/k);
						printf("\nMelhor solucao encontrada");
						escreve_sol(best, vert);
						printf("Custo final: %2d\n", best_custo);
						free(grafo);
						free(sol);
						free(best);
						return 0;
			case 2: /* ALGORITMO EVOLUTIVO */
					// Faz um ciclo com o n�mero de execu��es definidas
					for (r=0; r<runs; r++)
					{
				
						// Gera��o da popula��o inicial	
						pop = init_pop(EA_param); // pop tem um array de soluções (structs chrom), que dentro delas têm arrays de 1s e zeros
						// Avalia a popula��o inicial
					
						evaluate(pop, EA_param , matriz); // mat tem os dados direitinhos do ficheiro de texto

						// Como ainda n�o existe, escolhe-se como melhor solu��o a primeira da popula��o (poderia ser outra qualquer)
						best_run = pop[0];
						// Encontra-se a melhor solu��o dentro de toda a popula��o
						best_run = get_best(pop, EA_param, best_run);
						// Reserva espa�o para os pais da popula��o seguinte
						parents = malloc(sizeof(chrom)*EA_param.popsize);
						if (parents==NULL){
							printf("Erro na alocacao de memoria\n");
							exit(1);
						}
						
						// Ciclo de optimiza��o
						gen_actual = 1;
						while (gen_actual <= EA_param.numGenerations)
						{
							// Torneio bin�rio para encontrar os progenitores (ficam armazenados no vector parents)
							tournament(pop, EA_param, parents); // parents fica com uma série de soluções um pouco melhores que as anteriores, vai haver soluções repetidas, vão se perder algumas das soluções piores
							// Aplica os operadores gen�ticos aos pais (os descendentes ficam armazenados na estrutura pop)
							genetic_operators(parents, EA_param, pop); // pop fica com o crossover dos parents e da propria pop, e é aplicada mutação à pop
							// Avalia a nova popula��o (a dos filhos)
							evaluate(pop, EA_param, matriz); // calcula se é válida e o fitness de cada solução
							// Actualiza a melhor solu��o encontrada
							best_run = get_best(pop, EA_param, best_run);
							gen_actual++;
						}
						// Contagem das soluções inválidas
						for (inv=0, i=0; i<EA_param.popsize; i++)
							if (pop[i].valido == 0)
								inv++;
						// Escreve resultados da repeti��o que terminou
						printf("\nRepeticao %d:", r);
						write_best(best_run, EA_param);
						printf("Percentagem Invalidos: %.2f\n", 100*(float)inv/EA_param.popsize);
						printf("\n-----------\n");
						mbf += best_run.fitness;
						if (r==0 || best_run.fitness > best_ever.fitness)
							best_ever = best_run;
						// Liberta a mem�ria usada
						free(parents);
						free(pop);
	}
	
	// Escreve resultados globais
	printf("\n\n=============== RESULTADOS GLOBAIS ===============");
	printf("\nMBF: %f\n", mbf/r);			//Melhor fitness
	printf("\nMelhor solucao encontrada");
	write_best(best_ever, EA_param);
	return 0;

			case 3: /* Algoritmo HIBRIDO */


			case 4: /* SAIR */
				break;	
		
		default:
			break;
		}
	}
}

