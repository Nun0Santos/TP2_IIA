#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include "algoritmo.h"
#include "utils.h"
#include "funcao.h"
#include "utils.h"
#define MAX_OBJ 100 // Numero maximo (de objectos ) de numGenes