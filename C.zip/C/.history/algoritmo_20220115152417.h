#include "globals.h"
int trepa_colinas(int sol[], int *mat, int vert, int num_iter);

// EStrutura para armazenar parametros
struct info
{    // Tamanho da popula��o
    int     popsize; // número de soluções
    float   pm;   // Probabilidade de muta��o
    float   pr; // Probabilidade de recombina��o
	int     tsize; // Tamanho do torneio para sele��o do pai da pr�xima gera��o
	float   ro; // Constante para avalia��o com penaliza��o
    int     numGenes; // obj  numero máximo de objetos das nossas sol
	int     vert; //NumVertices
    int     *iter;
    int     numGenerations;  //max_gen
};

typedef struct individual chrom, *pchrom;
struct individual
{
    int     p[MAX_OBJ]; // tem 1 se o objeto pertence à solução, zero se não
	float   fitness; // Valor da qualidade da solução
	int     valido;// 1 se for uma solução válida e 0 se não for
};

void tournament(pchrom pop, struct info d, pchrom parents);
void genetic_operators(pchrom parents, struct info d, pchrom offspring);
void crossover(pchrom parents, struct info d, pchrom offspring);
void mutation(pchrom offspring,struct info d);