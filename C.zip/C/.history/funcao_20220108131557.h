int calcula_fit(int a[], int *mat, int vert);
int melhorVizinho(int a[], int b[], int c[], int *mat, int vert);