#include "globals.h"
int trepa_colinas(int sol[], int *mat, int vert, int num_iter);


// EStrutura para armazenar parametros
struct info
{    // Tamanho da popula��o
    int     popsize; // número de soluções
    float   pm;   // Probabilidade de muta��o
    float   pr; // Probabilidade de recombina��o
	int     tsize; // Tamanho do torneio para sele��o do pai da pr�xima gera��o
	float   ro; // Constante para avalia��o com penaliza��o
 //  int     numGenes; // obj // numero máximo de objetos das nossas sol
	int     vert; //NumVertices
    //
    int     *iter;
	// N�mero de gera��es
    int     numGenerations;  //max_gen
};

// Individuo (solu��o)
typedef struct individual chrom, *pchrom;

struct individual
{
    // Solu��o (objetos que est�o dentro da mochila)
    int     p[MAX_OBJ]; // tem 1 se o objeto pertence à solução, zero se não
    // Valor da qualidade da solu��o
	float   fitness;
    // 1 se for uma solu��o v�lida e 0 se n�o for
	int     valido;
};

void tournament(pchrom pop, struct info d, pchrom parents);

void genetic_operators(pchrom parents, struct info d, pchrom offspring);

void crossover(pchrom parents, struct info d, pchrom offspring);

void mutation(pchrom offspring,struct info d);