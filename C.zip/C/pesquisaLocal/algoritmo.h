#include "globals.h"

//void gera_vizinho(int a[], int b[], int c[], int n);
int trepa_colinas(int sol[], int *mat, int vert, int num_iter);
